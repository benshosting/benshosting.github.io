# Cheese Thrower🧀

This is a fun little extension where you can throw a cheese slice anywhere on your browser, inspired by the videos of people doing the same (e.g. <https://youtu.be/mFx2M1Gmy5g?si=saz4VUX00sdrHKH_>)

[Get it on the Chrome Web Store](https://chromewebstore.google.com/detail/cheese-thrower/ndlbdnipbodmfpilmiehbcdknnbaaenh)

![Example screenshot: person with cheese on his face](promo_images/mr-cheest-screenshot.png)